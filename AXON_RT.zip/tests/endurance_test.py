"""
AXON-RT ENDURANCE TEST
Tests if the 2056 optimization survives under sustained load.

Expected results on validated hardware:
- 90%+ win rate
- +8-10% average speedup
- Stable performance over time
"""
import time
import numpy as np
import sys
import os

def run_endurance(duration_seconds=60):
    print("=" * 60)
    print(f"  AXON-RT ENDURANCE TEST ({duration_seconds}s)")
    print("  Stress-testing the 'Resonance Shift' under heat.")
    print("=" * 60)
    
    # Shapes to compare
    TRAP_SIZE = 2048    # Power of 2 (cache conflict for float64)
    OPT_SIZE = 2056     # AXON-RT optimized (conflict broken)
    
    wins = 0
    losses = 0
    speedups = []
    lap = 0
    
    start_time = time.time()
    
    print(f"\n  Generating heat with float64...")
    
    while time.time() - start_time < duration_seconds:
        lap += 1
        elapsed = int(time.time() - start_time)
        
        # Test TRAP (2048)
        A_trap = np.random.rand(TRAP_SIZE, TRAP_SIZE).astype(np.float64)
        B_trap = np.random.rand(TRAP_SIZE, TRAP_SIZE).astype(np.float64)
        _ = np.dot(A_trap, B_trap)  # Warmup
        
        t_start = time.perf_counter()
        _ = np.dot(A_trap, B_trap)
        trap_time = time.perf_counter() - t_start
        
        # Test OPTIMIZED (2056)
        A_opt = np.random.rand(OPT_SIZE, OPT_SIZE).astype(np.float64)
        B_opt = np.random.rand(OPT_SIZE, OPT_SIZE).astype(np.float64)
        _ = np.dot(A_opt, B_opt)  # Warmup
        
        t_start = time.perf_counter()
        _ = np.dot(A_opt, B_opt)
        opt_time = time.perf_counter() - t_start
        
        # Calculate speedup
        speedup = (trap_time - opt_time) / trap_time * 100
        speedups.append(speedup)
        
        if speedup > 0:
            wins += 1
            status = "WIN"
            marker = "✓"
        else:
            losses += 1
            status = "LOSS"
            marker = "✗"
        
        print(f"  [{elapsed}s] Lap {lap}: Trap={trap_time:.3f}s | Opt={opt_time:.3f}s | "
              f"{marker} {status} (Speedup: {speedup:+.1f}%)")
    
    # Final stats
    total = wins + losses
    win_rate = (wins / total) * 100 if total > 0 else 0
    avg_speedup = sum(speedups) / len(speedups) if speedups else 0
    
    print("\n" + "=" * 60)
    print(f"  FINAL VERDICT: {wins} Wins / {total} Total ({win_rate:.1f}%)")
    print(f"  Avg Speedup:   {avg_speedup:+.1f}%")
    print("=" * 60)
    
    return {
        "wins": wins,
        "losses": losses,
        "total": total,
        "win_rate": win_rate,
        "avg_speedup": avg_speedup,
    }

if __name__ == "__main__":
    duration = 60
    if len(sys.argv) > 1:
        try:
            duration = int(sys.argv[1])
        except:
            pass
    
    run_endurance(duration)
