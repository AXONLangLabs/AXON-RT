"""
AXON-RT v0.1.2 Test: Dtype-Aware Shape Recommendations
=======================================================
Verifies that shape recommendations differ based on dtype.
"""

import numpy as np
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from axon_rt import AxonRT, HardwareProfile

def test_dtype_aware_shapes():
    """Test that float32 and float64 get different recommendations."""
    print("=" * 65)
    print("  AXON-RT v0.1.2 Test: Dtype-Aware Shape Recommendations")
    print("=" * 65)
    
    rt = AxonRT.auto_detect()
    
    print(f"\n  Runtime version: {rt.VERSION}")
    print(f"  Hardware: {rt.profile.hardware_id}")
    
    # Test at 2048 - the key case
    print("\n  TEST: Shape recommendation at 2048")
    print("  " + "-" * 50)
    
    rec_f32 = rt.recommend_shape((2048, 2048), dtype=np.float32)
    rec_f64 = rt.recommend_shape((2048, 2048), dtype=np.float64)
    
    print(f"  float32: {rec_f32.original} → {rec_f32.recommended} ({rec_f32.reasoning})")
    print(f"  float64: {rec_f64.original} → {rec_f64.recommended} ({rec_f64.reasoning})")
    
    # Verify they're different
    assert rec_f32.recommended == (2048, 2048), f"float32 should stay at 2048, got {rec_f32.recommended}"
    assert rec_f64.recommended == (2056, 2056), f"float64 should move to 2056, got {rec_f64.recommended}"
    
    print("\n  ✅ float32 stays at 2048 (aligned)")
    print("  ✅ float64 moves to 2056 (conflict broken)")
    
    # Test at 4096
    print("\n  TEST: Shape recommendation at 4096")
    print("  " + "-" * 50)
    
    rec_f32 = rt.recommend_shape((4096, 4096), dtype=np.float32)
    rec_f64 = rt.recommend_shape((4096, 4096), dtype=np.float64)
    
    print(f"  float32: {rec_f32.original} → {rec_f32.recommended}")
    print(f"  float64: {rec_f64.original} → {rec_f64.recommended}")
    
    assert rec_f32.recommended == (4096, 4096), f"float32 should stay at 4096"
    assert rec_f64.recommended == (4092, 4092), f"float64 should move to 4092"
    
    print("\n  ✅ float32 stays at 4096 (aligned)")
    print("  ✅ float64 moves to 4092 (conflict broken)")
    
    # Test report
    print("\n  TEST: Status report")
    print("  " + "-" * 50)
    
    report = rt.report()
    assert "DTYPE-AWARE" in report or "DTYPE-SPECIFIC" in report
    assert "float32" in report
    assert "float64" in report
    
    print("  ✅ Report includes dtype-specific information")
    
    # Summary
    print("\n" + "=" * 65)
    print("  ALL TESTS PASSED - AXON-RT v0.1.2 IS DTYPE-AWARE!")
    print("=" * 65)
    
    print("\n  The Physics:")
    print("  ─────────────")
    print("  Cache line = 64 bytes")
    print("  ")
    print("  float32 @ 2048: 2048 × 4 = 8192 bytes = 128 cache lines ✓")
    print("  float64 @ 2048: 2048 × 8 = 16384 bytes = 256 cache lines (CONFLICT!)")
    print("  float64 @ 2056: 2056 × 8 = 16448 bytes = 257 cache lines ✓")
    print("  ")
    print("  Different dtypes need different shapes!")
    print()

if __name__ == "__main__":
    test_dtype_aware_shapes()
