"""
QUANTUM DIVE: Dtype Resonance Analysis
Does the optimal shape change when particle size (dtype) changes?

This test proves the core AXON-RT discovery:
- float32 prefers 2048 (aligned to cache lines)
- float64 prefers 2056 (breaks cache conflict)
"""
import time
import numpy as np
import statistics
import sys

def run_test():
    print("=" * 65)
    print("  QUANTUM DIVE: Dtype Resonance Analysis")
    print("  Hypothesis: Sweet spots depend on byte-width (f32 vs f64)")
    print("=" * 65)

    shapes = [2048, 2056]
    dtypes = [np.float32, np.float64]
    trials = 15
    
    results = {
        "float32": {2048: [], 2056: []},
        "float64": {2048: [], 2056: []}
    }

    print("\n  Warming up...", end="", flush=True)
    A = np.random.rand(1024, 1024).astype(np.float64)
    for _ in range(10):
        np.dot(A, A)
    print(" done.")

    print(f"\n  Running {trials} interleaved trials per config...")
    
    for i in range(trials):
        sys.stdout.write(f"\r  Trial {i+1}/{trials}...")
        sys.stdout.flush()
        
        for dtype in dtypes:
            dt_name = dtype.__name__
            
            for s in shapes:
                A = np.random.rand(s, s).astype(dtype)
                B = np.random.rand(s, s).astype(dtype)
                
                _ = np.dot(A, B)
                
                start = time.perf_counter()
                for _ in range(20):
                    _ = np.dot(A, B)
                duration = (time.perf_counter() - start) / 20
                
                results[dt_name][s].append(duration)
    
    print("\n\n  RESULTS:")
    print("  " + "-" * 60)
    print(f"  {'DTYPE':<10} {'SHAPE':<7} {'MEAN (ms)':<12} {'STD':<10} {'CV%':<8} VERDICT")
    print("  " + "-" * 60)

    for dt_name in ["float32", "float64"]:
        times_2048 = results[dt_name][2048]
        times_2056 = results[dt_name][2056]
        
        mean_2048 = statistics.mean(times_2048) * 1000
        mean_2056 = statistics.mean(times_2056) * 1000
        std_2048 = statistics.stdev(times_2048) * 1000
        std_2056 = statistics.stdev(times_2056) * 1000
        cv_2048 = (std_2048 / mean_2048) * 100
        cv_2056 = (std_2056 / mean_2056) * 100
        
        speedup = (mean_2048 - mean_2056) / mean_2048 * 100
        
        if speedup > 3:
            verdict = f"2056 WINS ({speedup:+.1f}%)"
        elif speedup < -3:
            verdict = f"2048 WINS ({speedup:+.1f}%)"
        else:
            verdict = f"TIE ({speedup:+.1f}%)"
        
        print(f"  {dt_name:<10} 2048    {mean_2048:<12.2f} {std_2048:<10.2f} {cv_2048:<8.1f}")
        print(f"  {dt_name:<10} 2056    {mean_2056:<12.2f} {std_2056:<10.2f} {cv_2056:<8.1f} {verdict}")
        print("  " + "-" * 60)
    
    print("\n  HYPOTHESIS TEST:")
    print("  If float64 prefers 2056 but float32 prefers 2048,")
    print("  then AXON-RT must condition shape rules on dtype!")
    print("=" * 65)

if __name__ == "__main__":
    run_test()
