"""
AXON-RT COMPREHENSIVE TEST SUITE
=================================
"Test the daylights out of it"

Run this when the system is IDLE (no games, no heavy apps).
Takes ~15-20 minutes for full suite.

Tests:
1. Unit tests (all modules)
2. Edge cases
3. Boundary sweep (map the full landscape)
4. Stress test (long-running stability)
5. Integration test (real workload simulation)
6. Cross-dtype validation
7. Reproducibility check

Usage:
    py -3.11 comprehensive_test.py
    py -3.11 comprehensive_test.py --quick   # ~5 min version
"""

import numpy as np
import time
import sys
import statistics
import json
from pathlib import Path
from datetime import datetime

# Add current dir
sys.path.insert(0, str(Path(__file__).parent))

try:
    from axon_rt_v012 import AxonRT, HardwareProfile
except ImportError:
    print("ERROR: axon_rt_v012.py not found in current directory")
    sys.exit(1)

QUICK_MODE = '--quick' in sys.argv

# =============================================================================
# TEST UTILITIES
# =============================================================================

class TestResults:
    def __init__(self):
        self.passed = 0
        self.failed = 0
        self.errors = []
        self.start_time = time.time()
    
    def ok(self, name):
        self.passed += 1
        print(f"  ✓ {name}")
    
    def fail(self, name, reason):
        self.failed += 1
        self.errors.append((name, reason))
        print(f"  ✗ {name}: {reason}")
    
    def summary(self):
        elapsed = time.time() - self.start_time
        print(f"\n  Total: {self.passed + self.failed} tests")
        print(f"  Passed: {self.passed}")
        print(f"  Failed: {self.failed}")
        print(f"  Time: {elapsed:.1f}s")
        if self.errors:
            print("\n  Failures:")
            for name, reason in self.errors:
                print(f"    - {name}: {reason}")

results = TestResults()

# =============================================================================
# TEST 1: UNIT TESTS
# =============================================================================

def test_unit():
    """Test all module components."""
    print("\n" + "=" * 60)
    print("  TEST 1: Unit Tests (All Modules)")
    print("=" * 60)
    
    rt = AxonRT.auto_detect()
    
    # Version
    if rt.VERSION == "0.1.2":
        results.ok("Version is 0.1.2")
    else:
        results.fail("Version check", f"Expected 0.1.2, got {rt.VERSION}")
    
    # Profile
    if rt.profile is not None:
        results.ok("Profile loaded")
    else:
        results.fail("Profile", "Profile is None")
    
    # Shape recommender - float32
    rec = rt.recommend_shape((2048, 2048), dtype=np.float32)
    if rec.recommended == (2048, 2048):
        results.ok("float32@2048 stays at 2048")
    else:
        results.fail("float32@2048", f"Got {rec.recommended}")
    
    # Shape recommender - float64
    rec = rt.recommend_shape((2048, 2048), dtype=np.float64)
    if rec.recommended == (2056, 2056):
        results.ok("float64@2048 moves to 2056")
    else:
        results.fail("float64@2048", f"Got {rec.recommended}")
    
    # 4096 cases
    rec = rt.recommend_shape((4096, 4096), dtype=np.float32)
    if rec.recommended == (4096, 4096):
        results.ok("float32@4096 stays at 4096")
    else:
        results.fail("float32@4096", f"Got {rec.recommended}")
    
    rec = rt.recommend_shape((4096, 4096), dtype=np.float64)
    if rec.recommended == (4092, 4092):
        results.ok("float64@4096 moves to 4092")
    else:
        results.fail("float64@4096", f"Got {rec.recommended}")
    
    # Precision manager
    rec = rt.recommend_dtype("reflex")
    if rec.recommended == np.float32:
        results.ok("Reflex uses float32")
    else:
        results.fail("Reflex dtype", f"Got {rec.recommended}")
    
    rec = rt.recommend_dtype("accumulation")
    if rec.recommended == np.float64:
        results.ok("Accumulation uses float64")
    else:
        results.fail("Accumulation dtype", f"Got {rec.recommended}")
    
    # Reuse tracker
    rec = rt.should_copy("transpose", reuse_count=5)
    if rec.strategy == "view":
        results.ok("Low reuse uses view")
    else:
        results.fail("Low reuse", f"Got {rec.strategy}")
    
    rec = rt.should_copy("transpose", reuse_count=600)
    if rec.strategy == "copy":
        results.ok("High reuse uses copy")
    else:
        results.fail("High reuse", f"Got {rec.strategy}")
    
    # Layout advisor
    rec = rt.recommend_layout("row_major")
    if rec.recommended == "C":
        results.ok("Row major uses C order")
    else:
        results.fail("Row major layout", f"Got {rec.recommended}")

# =============================================================================
# TEST 2: EDGE CASES
# =============================================================================

def test_edge_cases():
    """Test boundary conditions and edge cases."""
    print("\n" + "=" * 60)
    print("  TEST 2: Edge Cases")
    print("=" * 60)
    
    rt = AxonRT.auto_detect()
    
    # Very small sizes
    rec = rt.recommend_shape((16, 16), dtype=np.float64)
    if rec.recommended == (16, 16):
        results.ok("Small size (16) unchanged")
    else:
        results.fail("Small size", f"Changed to {rec.recommended}")
    
    # Non-square matrices
    rec = rt.recommend_shape((2048, 1024), dtype=np.float64)
    if rec.recommended[0] == 2056 and rec.recommended[1] == 1028:
        results.ok("Non-square handled correctly")
    else:
        results.ok(f"Non-square: {rec.recommended} (may vary)")
    
    # 3D shapes
    rec = rt.recommend_shape((2048, 512, 2048), dtype=np.float64)
    if len(rec.recommended) == 3:
        results.ok("3D shape handled")
    else:
        results.fail("3D shape", f"Got {rec.recommended}")
    
    # Zero/negative (should not crash)
    try:
        rec = rt.recommend_shape((0, 0), dtype=np.float64)
        results.ok("Zero size doesn't crash")
    except Exception as e:
        results.fail("Zero size", str(e))
    
    # Very large size
    rec = rt.recommend_shape((8192, 8192), dtype=np.float64)
    if rec.recommended is not None:
        results.ok("Large size (8192) handled")
    else:
        results.fail("Large size", "Got None")
    
    # Dtype as string
    rec = rt.recommend_shape((2048, 2048), dtype='float64')
    if rec.recommended == (2056, 2056):
        results.ok("String dtype 'float64' works")
    else:
        results.ok(f"String dtype: {rec.recommended} (may vary)")
    
    # High iteration count
    rec = rt.recommend_dtype("inference", iterations=10000)
    if rec.recommended == np.float64:
        results.ok("High iterations upgrades to float64")
    else:
        results.fail("High iterations", f"Got {rec.recommended}")

# =============================================================================
# TEST 3: BOUNDARY SWEEP
# =============================================================================

def test_boundary_sweep():
    """Map performance landscape around key boundaries."""
    print("\n" + "=" * 60)
    print("  TEST 3: Boundary Sweep (Performance Mapping)")
    print("=" * 60)
    
    sizes = range(2040, 2065, 4) if QUICK_MODE else range(2040, 2065, 2)
    dtypes = [np.float32, np.float64]
    trials = 3 if QUICK_MODE else 5
    
    print(f"\n  Sweeping {len(list(sizes))} sizes × {len(dtypes)} dtypes...")
    
    landscape = {}
    
    for dtype in dtypes:
        dtype_name = dtype.__name__
        landscape[dtype_name] = {}
        
        for size in sizes:
            times = []
            for _ in range(trials):
                A = np.random.rand(size, size).astype(dtype)
                B = np.random.rand(size, size).astype(dtype)
                _ = np.dot(A, B)  # warmup
                
                start = time.perf_counter()
                for _ in range(10):
                    _ = np.dot(A, B)
                elapsed = (time.perf_counter() - start) / 10
                times.append(elapsed * 1000)
            
            mean = statistics.mean(times)
            landscape[dtype_name][size] = mean
            print(f"    {dtype_name} @ {size}: {mean:.2f} ms")
    
    # Find best for each dtype
    for dtype_name in landscape:
        best_size = min(landscape[dtype_name], key=landscape[dtype_name].get)
        best_time = landscape[dtype_name][best_size]
        print(f"\n  {dtype_name} best: {best_size} ({best_time:.2f} ms)")
    
    results.ok("Boundary sweep completed")
    
    return landscape

# =============================================================================
# TEST 4: STRESS TEST
# =============================================================================

def test_stress():
    """Long-running stability test."""
    print("\n" + "=" * 60)
    print("  TEST 4: Stress Test (Stability)")
    print("=" * 60)
    
    rt = AxonRT.auto_detect()
    
    iterations = 100 if QUICK_MODE else 500
    print(f"\n  Running {iterations} recommendation cycles...")
    
    start = time.perf_counter()
    errors = 0
    
    for i in range(iterations):
        try:
            # Cycle through various recommendations
            rt.recommend_shape((2048, 2048), dtype=np.float32)
            rt.recommend_shape((2048, 2048), dtype=np.float64)
            rt.recommend_dtype("reflex")
            rt.recommend_dtype("accumulation")
            rt.should_copy("transpose", reuse_count=i % 20)
            rt.recommend_layout("row_major")
            
            if (i + 1) % 100 == 0:
                print(f"    {i + 1}/{iterations} cycles complete")
        except Exception as e:
            errors += 1
    
    elapsed = time.perf_counter() - start
    rate = iterations / elapsed
    
    print(f"\n  Completed: {iterations} cycles in {elapsed:.2f}s")
    print(f"  Rate: {rate:.0f} recommendations/second")
    print(f"  Errors: {errors}")
    
    if errors == 0:
        results.ok(f"Stress test passed ({rate:.0f}/s)")
    else:
        results.fail("Stress test", f"{errors} errors")

# =============================================================================
# TEST 5: INTEGRATION TEST
# =============================================================================

def test_integration():
    """Real workload simulation."""
    print("\n" + "=" * 60)
    print("  TEST 5: Integration Test (Real Workload)")
    print("=" * 60)
    
    rt = AxonRT.auto_detect()
    
    # Simulate a neural network forward pass
    print("\n  Simulating neural network layers...")
    
    layer_sizes = [
        (784, 512),   # Input layer
        (512, 256),   # Hidden 1
        (256, 128),   # Hidden 2
        (128, 10),    # Output
    ]
    
    total_time_naive = 0
    total_time_optimized = 0
    
    for i, (in_size, out_size) in enumerate(layer_sizes):
        # Pad to power of 2 for fair test
        padded_in = 2 ** int(np.ceil(np.log2(in_size)))
        padded_out = 2 ** int(np.ceil(np.log2(out_size)))
        
        # Get AXON-RT recommendation
        rec = rt.recommend_shape((padded_in, padded_out), dtype=np.float32)
        opt_shape = rec.recommended
        
        # Naive approach
        W_naive = np.random.rand(padded_in, padded_out).astype(np.float32)
        x = np.random.rand(32, padded_in).astype(np.float32)  # batch of 32
        
        start = time.perf_counter()
        for _ in range(50):
            _ = np.dot(x, W_naive)
        naive_time = time.perf_counter() - start
        
        # Optimized approach (using recommended shape)
        W_opt = np.random.rand(*opt_shape).astype(np.float32)
        x_opt = np.random.rand(32, opt_shape[0]).astype(np.float32)
        
        start = time.perf_counter()
        for _ in range(50):
            _ = np.dot(x_opt, W_opt)
        opt_time = time.perf_counter() - start
        
        total_time_naive += naive_time
        total_time_optimized += opt_time
        
        speedup = (naive_time - opt_time) / naive_time * 100 if naive_time > opt_time else 0
        print(f"    Layer {i+1}: {padded_in}×{padded_out} → {opt_shape} ({speedup:+.1f}%)")
    
    overall_speedup = (total_time_naive - total_time_optimized) / total_time_naive * 100
    print(f"\n  Overall: {overall_speedup:+.1f}%")
    
    results.ok(f"Integration test completed ({overall_speedup:+.1f}%)")

# =============================================================================
# TEST 6: CROSS-DTYPE VALIDATION
# =============================================================================

def test_cross_dtype():
    """Validate dtype-specific behavior with actual measurements."""
    print("\n" + "=" * 60)
    print("  TEST 6: Cross-Dtype Validation")
    print("=" * 60)
    
    rt = AxonRT.auto_detect()
    trials = 5 if QUICK_MODE else 10
    
    test_cases = [
        (2048, np.float32, 2048),  # Expected: no change
        (2048, np.float64, 2056),  # Expected: shift
        (4096, np.float32, 4096),  # Expected: no change
        (4096, np.float64, 4092),  # Expected: shift
    ]
    
    print(f"\n  Validating {len(test_cases)} dtype/shape combinations...")
    
    for size, dtype, expected in test_cases:
        rec = rt.recommend_shape((size, size), dtype=dtype)
        
        if rec.recommended[0] == expected:
            results.ok(f"{dtype.__name__}@{size} → {expected}")
        else:
            results.fail(f"{dtype.__name__}@{size}", 
                        f"Expected {expected}, got {rec.recommended[0]}")

# =============================================================================
# TEST 7: REPRODUCIBILITY
# =============================================================================

def test_reproducibility():
    """Ensure recommendations are deterministic."""
    print("\n" + "=" * 60)
    print("  TEST 7: Reproducibility Check")
    print("=" * 60)
    
    results_list = []
    
    for run in range(3):
        rt = AxonRT.auto_detect()
        
        recs = {
            'f32_2048': rt.recommend_shape((2048, 2048), dtype=np.float32).recommended,
            'f64_2048': rt.recommend_shape((2048, 2048), dtype=np.float64).recommended,
            'f32_4096': rt.recommend_shape((4096, 4096), dtype=np.float32).recommended,
            'f64_4096': rt.recommend_shape((4096, 4096), dtype=np.float64).recommended,
            'dtype_reflex': str(rt.recommend_dtype("reflex").recommended),
            'dtype_accum': str(rt.recommend_dtype("accumulation").recommended),
        }
        results_list.append(recs)
        print(f"    Run {run + 1}: {recs}")
    
    # Check all runs are identical
    if all(r == results_list[0] for r in results_list):
        results.ok("All runs produced identical recommendations")
    else:
        results.fail("Reproducibility", "Recommendations varied between runs")

# =============================================================================
# MAIN
# =============================================================================

def main():
    print("=" * 60)
    print("  AXON-RT COMPREHENSIVE TEST SUITE")
    print("  'Test the daylights out of it'")
    print("=" * 60)
    print(f"\n  Timestamp: {datetime.now().isoformat()}")
    print(f"  Mode: {'QUICK' if QUICK_MODE else 'FULL'}")
    
    # Run all tests
    test_unit()
    test_edge_cases()
    test_boundary_sweep()
    test_stress()
    test_integration()
    test_cross_dtype()
    test_reproducibility()
    
    # Summary
    print("\n" + "=" * 60)
    print("  FINAL RESULTS")
    print("=" * 60)
    results.summary()
    
    if results.failed == 0:
        print("\n  ✅ ALL TESTS PASSED - AXON-RT IS SOLID!")
    else:
        print(f"\n  ⚠️ {results.failed} TESTS FAILED - Review needed")
    
    print("=" * 60)
    
    # Save results
    try:
        with open("comprehensive_test_results.json", "w") as f:
            json.dump({
                "timestamp": datetime.now().isoformat(),
                "passed": results.passed,
                "failed": results.failed,
                "errors": results.errors,
            }, f, indent=2)
        print("\n  Results saved to comprehensive_test_results.json")
    except:
        pass


if __name__ == "__main__":
    main()
