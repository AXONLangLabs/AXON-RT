"""
AXON-RT Hardware Benchmark Suite
=================================
Measures actual hardware performance to replace estimated values
with real measurements for your specific machine.

Tests:
1. float32 vs float64 speedup
2. Shape sweet spots (powers of 2 vs nearby)
3. Transpose copy breakeven
4. Cache behavior

Output: alienware_measured_profile.json

Usage:
    py -3.11 benchmark_hardware.py
    py -3.11 benchmark_hardware.py --quick   # Faster, less accurate
"""

import numpy as np
import time
import json
import os
import sys
import statistics
from datetime import datetime
from pathlib import Path

# =============================================================================
# CONFIGURATION
# =============================================================================

# Measurement settings
MIN_TIME = 0.200  # Minimum seconds per measurement
N_MEASUREMENTS = 5  # Number of measurements per test
WARMUP_SECONDS = 2.0

# Quick mode (less accurate but faster)
QUICK_MIN_TIME = 0.100
QUICK_N_MEASUREMENTS = 3
QUICK_WARMUP = 1.0

# =============================================================================
# SETUP
# =============================================================================

def setup():
    """Set up environment."""
    print("\n" + "=" * 60)
    print("  AXON-RT Hardware Benchmark Suite")
    print("  Measuring YOUR hardware for accurate optimization rules")
    print("=" * 60)
    
    # Set single-threaded for consistent results
    for var in ['OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'OPENBLAS_NUM_THREADS']:
        os.environ[var] = '1'
    
    np.random.seed(42)
    
    # Try to set process priority
    try:
        import psutil
        p = psutil.Process()
        if sys.platform == 'win32':
            p.nice(psutil.HIGH_PRIORITY_CLASS)
        print("  ✓ High priority set")
    except:
        print("  ⚠ Could not set priority (install psutil for better results)")
    
    # Get hardware info
    print(f"  ✓ Python {sys.version.split()[0]}")
    print(f"  ✓ NumPy {np.__version__}")
    
    return True


def warmup(duration):
    """Warm up CPU."""
    print(f"\n  Warming up ({duration}s)...", end=" ", flush=True)
    A = np.random.rand(500, 500).astype(np.float64)
    start = time.perf_counter()
    while time.perf_counter() - start < duration:
        _ = np.dot(A, A)
    print("done")


# =============================================================================
# BENCHMARK CORE
# =============================================================================

def benchmark_matmul(size, dtype, min_time, n_meas):
    """Benchmark matrix multiplication."""
    gflops_list = []
    time_list = []
    
    flops = 2 * size * size * size
    
    for _ in range(n_meas):
        A = np.random.rand(size, size).astype(dtype)
        B = np.random.rand(size, size).astype(dtype)
        
        # Warmup
        _ = np.dot(A, B)
        
        # Measure
        count = 0
        start = time.perf_counter()
        while True:
            _ = np.dot(A, B)
            count += 1
            elapsed = time.perf_counter() - start
            if elapsed >= min_time:
                break
        
        gflops = (count * flops / elapsed) / 1e9
        time_per_op = elapsed / count
        
        gflops_list.append(gflops)
        time_list.append(time_per_op)
        
        del A, B
    
    return {
        'size': size,
        'dtype': str(dtype),
        'mean_gflops': statistics.mean(gflops_list),
        'mean_time_ms': statistics.mean(time_list) * 1000,
        'std_gflops': statistics.stdev(gflops_list) if len(gflops_list) > 1 else 0,
    }


# =============================================================================
# TEST 1: DTYPE COMPARISON
# =============================================================================

def test_dtype_speedup(min_time, n_meas):
    """Measure float32 vs float64 speedup."""
    print("\n" + "-" * 60)
    print("  TEST 1: float32 vs float64 Speedup")
    print("-" * 60)
    
    sizes = [256, 512, 1024, 2048]
    results = []
    
    print(f"\n  {'Size':>6}  {'float32':>10}  {'float64':>10}  {'Speedup':>8}  {'Time Saved':>10}")
    print("  " + "-" * 50)
    
    for size in sizes:
        f32 = benchmark_matmul(size, np.float32, min_time, n_meas)
        f64 = benchmark_matmul(size, np.float64, min_time, n_meas)
        
        speedup = f32['mean_gflops'] / f64['mean_gflops']
        time_saved = (1 - f64['mean_gflops'] / f32['mean_gflops']) * 100
        
        results.append({
            'size': size,
            'float32_gflops': f32['mean_gflops'],
            'float64_gflops': f64['mean_gflops'],
            'speedup': speedup,
            'time_saved_pct': time_saved,
        })
        
        print(f"  {size:>6}  {f32['mean_gflops']:>10.1f}  {f64['mean_gflops']:>10.1f}  "
              f"{speedup:>7.2f}x  {time_saved:>9.1f}%")
    
    avg_speedup = statistics.mean([r['speedup'] for r in results])
    avg_time_saved = statistics.mean([r['time_saved_pct'] for r in results])
    
    print("  " + "-" * 50)
    print(f"  {'AVG':>6}  {'-':>10}  {'-':>10}  {avg_speedup:>7.2f}x  {avg_time_saved:>9.1f}%")
    
    return {
        'float32_speedup': round(avg_speedup, 2),
        'time_saved_pct': round(avg_time_saved, 1),
        'details': results
    }


# =============================================================================
# TEST 2: SHAPE SWEET SPOTS
# =============================================================================

def test_shape_sweet_spots(min_time, n_meas):
    """Test powers of 2 vs nearby sizes."""
    print("\n" + "-" * 60)
    print("  TEST 2: Shape Sweet Spots (Powers of 2 vs Nearby)")
    print("-" * 60)
    
    # Test key sizes
    test_cases = [
        (1024, [1020, 1024, 1028, 1032]),
        (2048, [2040, 2048, 2056, 2064]),
        (4096, [4088, 4092, 4096, 4100]),
    ]
    
    sweet_spots = {}
    
    for base, sizes in test_cases:
        print(f"\n  Testing around {base}:")
        results = []
        
        for size in sizes:
            r = benchmark_matmul(size, np.float64, min_time, n_meas)
            results.append(r)
            marker = " ← 2^n" if size == base else ""
            print(f"    {size}: {r['mean_gflops']:.1f} GFLOPS{marker}")
        
        # Find best
        best = max(results, key=lambda x: x['mean_gflops'])
        pow2_result = next(r for r in results if r['size'] == base)
        
        if best['size'] != base:
            gain = (best['mean_gflops'] / pow2_result['mean_gflops'] - 1) * 100
            print(f"    → Best: {best['size']} (+{gain:.1f}% vs {base})")
            sweet_spots[base] = best['size']
        else:
            print(f"    → Power of 2 ({base}) is optimal")
            sweet_spots[base] = base
    
    return {
        'sweet_spots': sweet_spots,
        'pow2_is_best': all(sweet_spots[k] == k for k in sweet_spots)
    }


# =============================================================================
# TEST 3: TRANSPOSE BREAKEVEN
# =============================================================================

def test_transpose_breakeven(min_time, n_meas):
    """Find the breakeven point for copy vs view."""
    print("\n" + "-" * 60)
    print("  TEST 3: Transpose Copy Breakeven")
    print("-" * 60)
    
    size = 512
    dtype = np.float64
    
    # Create test matrices
    A = np.random.rand(size, size).astype(dtype)
    B = np.random.rand(size, size).astype(dtype)
    
    # Measure copy overhead
    print("\n  Measuring copy overhead...")
    copy_times = []
    for _ in range(n_meas):
        start = time.perf_counter()
        for _ in range(100):
            A_copy = np.ascontiguousarray(A.T)
        elapsed = time.perf_counter() - start
        copy_times.append(elapsed / 100)
    
    copy_overhead = statistics.mean(copy_times) * 1000  # ms
    print(f"    Copy overhead: {copy_overhead:.3f} ms")
    
    # Measure view matmul
    print("  Measuring view vs copy matmul...")
    
    view_times = []
    copy_matmul_times = []
    
    A_T = A.T  # View
    A_T_copy = np.ascontiguousarray(A.T)  # Copy
    
    for _ in range(n_meas):
        # View path
        start = time.perf_counter()
        for _ in range(50):
            _ = np.dot(A_T, B)
        view_time = (time.perf_counter() - start) / 50
        view_times.append(view_time)
        
        # Copy path (already copied)
        start = time.perf_counter()
        for _ in range(50):
            _ = np.dot(A_T_copy, B)
        copy_time = (time.perf_counter() - start) / 50
        copy_matmul_times.append(copy_time)
    
    view_matmul = statistics.mean(view_times) * 1000
    copy_matmul = statistics.mean(copy_matmul_times) * 1000
    
    savings_per_matmul = view_matmul - copy_matmul
    
    print(f"    View matmul:  {view_matmul:.3f} ms")
    print(f"    Copy matmul:  {copy_matmul:.3f} ms")
    print(f"    Savings/op:   {savings_per_matmul:.3f} ms")
    
    if savings_per_matmul > 0:
        breakeven = copy_overhead / savings_per_matmul
        print(f"\n  → Breakeven: {breakeven:.1f} matmuls")
        print(f"    Copy if reuse >= {int(breakeven) + 1}")
    else:
        breakeven = float('inf')
        print(f"\n  → Copy never pays off (view is always faster)")
    
    return {
        'copy_overhead_ms': round(copy_overhead, 3),
        'savings_per_matmul_ms': round(savings_per_matmul, 3),
        'breakeven': round(breakeven, 1) if breakeven != float('inf') else 999,
        'view_penalty_pct': round((view_matmul / copy_matmul - 1) * 100, 1) if copy_matmul > 0 else 0
    }


# =============================================================================
# TEST 4: SMALL SIZE BEHAVIOR
# =============================================================================

def test_small_sizes(min_time, n_meas):
    """Test if powers of 2 are optimal at small sizes."""
    print("\n" + "-" * 60)
    print("  TEST 4: Small Size Behavior (≤512)")
    print("-" * 60)
    
    # Test 256 and 512
    test_cases = [
        (256, [248, 252, 256, 260, 264]),
        (512, [504, 508, 512, 516, 520]),
    ]
    
    pow2_optimal = True
    
    for base, sizes in test_cases:
        print(f"\n  Testing around {base}:")
        results = []
        
        for size in sizes:
            r = benchmark_matmul(size, np.float64, min_time, n_meas)
            results.append(r)
            marker = " ← 2^n" if size == base else ""
            print(f"    {size}: {r['mean_gflops']:.1f} GFLOPS{marker}")
        
        best = max(results, key=lambda x: x['mean_gflops'])
        if best['size'] != base:
            pow2_optimal = False
            print(f"    → Best: {best['size']} (not power of 2!)")
        else:
            print(f"    → Power of 2 ({base}) is optimal ✓")
    
    return {
        'pow2_optimal_small': pow2_optimal,
        'threshold': 512 if pow2_optimal else 256
    }


# =============================================================================
# GENERATE PROFILE
# =============================================================================

def generate_profile(results, output_path):
    """Generate hardware profile JSON."""
    
    profile = {
        "profile_version": "0.1.1",
        "hardware_id": os.environ.get('COMPUTERNAME', 'unknown'),
        "timestamp": datetime.now().isoformat(),
        "measured": True,
        
        "cpu_arch": "AMD64",
        "blas_backend": "openblas",
        
        # Measured values
        "float32_speedup": results['dtype']['float32_speedup'],
        "transpose_breakeven": results['transpose']['breakeven'],
        "pow2_threshold": results['small_sizes']['threshold'],
        
        # Sweet spots
        "sweet_spots": {
            "256": 256,
            "512": 512,
            **{str(k): v for k, v in results['shape']['sweet_spots'].items()}
        },
        
        # Detailed results
        "benchmark_results": results
    }
    
    with open(output_path, 'w') as f:
        json.dump(profile, f, indent=2)
    
    print(f"\n  ✓ Profile saved: {output_path}")
    return profile


# =============================================================================
# MAIN
# =============================================================================

def main():
    quick_mode = '--quick' in sys.argv
    
    if quick_mode:
        min_time = QUICK_MIN_TIME
        n_meas = QUICK_N_MEASUREMENTS
        warmup_time = QUICK_WARMUP
        print("\n  [QUICK MODE - Less accurate but faster]")
    else:
        min_time = MIN_TIME
        n_meas = N_MEASUREMENTS
        warmup_time = WARMUP_SECONDS
    
    setup()
    warmup(warmup_time)
    
    results = {}
    
    # Run tests
    results['dtype'] = test_dtype_speedup(min_time, n_meas)
    results['shape'] = test_shape_sweet_spots(min_time, n_meas)
    results['transpose'] = test_transpose_breakeven(min_time, n_meas)
    results['small_sizes'] = test_small_sizes(min_time, n_meas)
    
    # Summary
    print("\n" + "=" * 60)
    print("  SUMMARY: YOUR ALIENWARE MEASURED VALUES")
    print("=" * 60)
    
    print(f"""
  float32 speedup:      {results['dtype']['float32_speedup']:.2f}x
  Time saved:           {results['dtype']['time_saved_pct']:.1f}%
  
  Transpose breakeven:  {results['transpose']['breakeven']:.1f} matmuls
  View penalty:         {results['transpose']['view_penalty_pct']:.1f}%
  
  Power-of-2 threshold: ≤{results['small_sizes']['threshold']}
  Sweet spots:          {results['shape']['sweet_spots']}
    """)
    
    # Generate profile
    output_path = Path("alienware_measured_profile.json")
    profile = generate_profile(results, output_path)
    
    print("\n" + "=" * 60)
    print("  BENCHMARK COMPLETE")
    print("=" * 60)
    print(f"\n  Use this profile with AXON-RT:")
    print(f"    rt = AxonRT.from_profile('{output_path}')")
    print()


if __name__ == "__main__":
    main()
