"""
AXON-RT CLI Entry Point
"""
from .axon_rt import main

if __name__ == "__main__":
    main()
