"""
AXON-RT - Adaptive eXecution Optimization Network Runtime
==========================================================

A dtype-aware numerical optimization runtime that delivers free 
performance gains by understanding cache physics.

Usage:
    from axon_rt import AxonRT
    import numpy as np
    
    rt = AxonRT.auto_detect()
    rec = rt.recommend_shape((2048, 2048), dtype=np.float64)
    print(rec.recommended)  # (2056, 2056)

Version: 0.1.2
"""

from .axon_rt import (
    AxonRT,
    HardwareProfile,
    ShapeRecommendation,
    DtypeRecommendation,
    CopyRecommendation,
    LayoutRecommendation,
    PrecisionManager,
    ShapeRecommender,
    ReuseTracker,
    LayoutAdvisor,
)

__version__ = "0.1.2"
__author__ = "Daniel & The AXON Team"

__all__ = [
    "AxonRT",
    "HardwareProfile",
    "ShapeRecommendation",
    "DtypeRecommendation",
    "CopyRecommendation",
    "LayoutRecommendation",
    "PrecisionManager",
    "ShapeRecommender",
    "ReuseTracker",
    "LayoutAdvisor",
]
