"""
AXON-RT v0.1.2 - Dtype-Aware Shape Recommendations
====================================================
BREAKTHROUGH: Shape sweet spots depend on dtype!

Discovery from Quantum Dive experiment:
- float32 @ 2048: Optimal (128 cache lines, aligned)
- float64 @ 2048: Trap (256 cache lines, conflict)
- float64 @ 2056: Optimal (257 cache lines, breaks conflict)

This version conditions shape recommendations on dtype.

Author: Daniel & Team (Claude, ChatGPT, Copilot, Grok, Gemini)
License: MIT
Version: 0.1.2
"""

import numpy as np
import json
import math
import logging
from io import StringIO
from pathlib import Path
from dataclasses import dataclass, field, asdict
from typing import Dict, List, Tuple, Optional, Union, Literal
from datetime import datetime

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("AXON-RT")

# =============================================================================
# DATA CLASSES
# =============================================================================

@dataclass
class ShapeRecommendation:
    """Result of shape optimization."""
    original: Tuple[int, ...]
    recommended: Tuple[int, ...]
    estimated_gain_pct: float
    reasoning: str
    confidence: Literal["high", "medium", "low"]
    dtype: str = "float64"
    note: str = "Estimates based on dtype-specific cache behavior"

@dataclass
class DtypeRecommendation:
    """Result of dtype selection."""
    recommended: np.dtype
    reasoning: str
    estimated_speedup: float
    precision_tradeoff: str

@dataclass
class CopyRecommendation:
    """Result of copy vs view decision."""
    strategy: Literal["view", "copy"]
    reasoning: str
    breakeven: float
    reuse_count: int

@dataclass
class LayoutRecommendation:
    """Result of layout optimization."""
    recommended: Literal["C", "F"]
    reasoning: str
    contiguous_required: bool

@dataclass
class HardwareProfile:
    """
    Hardware characteristics for optimization decisions.
    
    v0.1.2: Now includes DTYPE-SPECIFIC sweet spots!
    """
    profile_version: str = "0.1.2"
    hardware_id: str = ""
    timestamp: str = ""
    
    cpu_arch: str = "unknown"
    cpu_cores_physical: int = 1
    cpu_cores_logical: int = 1
    cache_line_bytes: int = 64
    
    gpu_present: bool = False
    gpu_name: str = ""
    
    blas_backend: str = "unknown"
    
    # Benchmark results
    float32_speedup: float = 1.92
    transpose_breakeven: float = 518.0
    
    # NEW in v0.1.2: DTYPE-SPECIFIC SWEET SPOTS
    # The key discovery: optimal shape depends on dtype!
    sweet_spots_float32: Dict[int, int] = field(default_factory=lambda: {
        256: 256,    # Aligned
        512: 512,    # Aligned
        1024: 1024,  # Aligned (float32 likes powers of 2)
        2048: 2048,  # Aligned (float32 likes powers of 2)
        4096: 4096,  # Aligned
    })
    
    sweet_spots_float64: Dict[int, int] = field(default_factory=lambda: {
        256: 256,    # Small enough, no conflict
        512: 512,    # Small enough
        1024: 1028,  # Break conflict (+0.5%)
        2048: 2056,  # Break conflict (+5.5%)
        4096: 4092,  # Break conflict (+5.3%)
    })
    
    # Gains for each (measured)
    gains_float32: Dict[int, float] = field(default_factory=lambda: {
        256: 0.0, 512: 0.0, 1024: 0.0, 2048: 0.0, 4096: 0.0
    })
    
    gains_float64: Dict[int, float] = field(default_factory=lambda: {
        256: 0.0, 512: 0.0, 1024: 0.5, 2048: 5.5, 4096: 5.3
    })
    
    def to_json(self) -> str:
        data = asdict(self)
        # Convert int keys to strings for JSON
        for key in ['sweet_spots_float32', 'sweet_spots_float64', 'gains_float32', 'gains_float64']:
            if key in data:
                data[key] = {str(k): v for k, v in data[key].items()}
        return json.dumps(data, indent=2)
    
    @classmethod
    def from_json(cls, json_str: str) -> 'HardwareProfile':
        data = json.loads(json_str)
        # Convert string keys back to ints
        for key in ['sweet_spots_float32', 'sweet_spots_float64', 'gains_float32', 'gains_float64']:
            if key in data:
                data[key] = {int(k): v for k, v in data[key].items()}
        return cls(**data)
    
    @classmethod
    def from_file(cls, path: str) -> 'HardwareProfile':
        with open(path, 'r') as f:
            return cls.from_json(f.read())
    
    def save(self, path: str):
        with open(path, 'w') as f:
            f.write(self.to_json())
        logger.info(f"Profile saved to {path}")

# =============================================================================
# PRECISION MANAGER
# =============================================================================

class PrecisionManager:
    """Select optimal data type based on workload."""
    
    WORKLOAD_DEFAULTS = {
        "reflex": np.float32,
        "inference": np.float32,
        "training": np.float32,
        "accumulation": np.float64,
        "precision": np.float64,
    }
    
    def __init__(self, profile: HardwareProfile):
        self.profile = profile
        self.speedup_f32_vs_f64 = profile.float32_speedup
    
    def recommend(self, workload: str = "inference",
                  required_precision: str = "medium",
                  iterations: int = 1) -> DtypeRecommendation:
        
        default_dtype = self.WORKLOAD_DEFAULTS.get(workload, np.float32)
        
        if iterations > 1000 and workload != "precision":
            return DtypeRecommendation(
                np.float64,
                f"Upgrading to float64 for {iterations} iterations (drift prevention)",
                1.0,
                "Accuracy over speed"
            )
        
        if required_precision in ["high", "maximum"]:
            return DtypeRecommendation(
                np.float64,
                f"High precision required, using float64",
                1.0,
                "Maximum precision"
            )
        
        speedup = self.speedup_f32_vs_f64 if default_dtype == np.float32 else 1.0
        return DtypeRecommendation(
            default_dtype,
            f"Using {default_dtype.__name__} for '{workload}' (~{speedup:.2f}x vs float64)",
            speedup,
            "Balanced"
        )

# =============================================================================
# SHAPE RECOMMENDER (v0.1.2 - DTYPE AWARE!)
# =============================================================================

class ShapeRecommender:
    """
    Suggest optimal matrix dimensions based on cache behavior.
    
    v0.1.2 BREAKTHROUGH: Shape recommendations now depend on dtype!
    
    The physics:
    - Cache lines are 64 bytes
    - float32: 16 elements per cache line
    - float64: 8 elements per cache line
    
    At 2048:
    - float32: 2048 * 4 = 8192 bytes = 128 cache lines (aligned, good!)
    - float64: 2048 * 8 = 16384 bytes = 256 cache lines (conflict!)
    
    At 2056:
    - float32: 2056 * 4 = 8224 bytes = 128.5 cache lines (misaligned, bad!)
    - float64: 2056 * 8 = 16448 bytes = 257 cache lines (conflict broken, good!)
    """
    
    def __init__(self, profile: HardwareProfile):
        self.profile = profile
        
        # Load dtype-specific sweet spots
        self.sweet_spots = {
            np.float32: profile.sweet_spots_float32,
            np.float64: profile.sweet_spots_float64,
            'float32': profile.sweet_spots_float32,
            'float64': profile.sweet_spots_float64,
        }
        
        self.gains = {
            np.float32: profile.gains_float32,
            np.float64: profile.gains_float64,
            'float32': profile.gains_float32,
            'float64': profile.gains_float64,
        }
        
        logger.info(f"ShapeRecommender loaded dtype-aware sweet spots")
        logger.info(f"  float32: {profile.sweet_spots_float32}")
        logger.info(f"  float64: {profile.sweet_spots_float64}")
    
    def recommend(self, target: Tuple[int, ...], 
                  dtype=np.float64,
                  flexibility: str = "relaxed") -> ShapeRecommendation:
        """
        Recommend optimal shape for given target and dtype.
        
        Args:
            target: Target shape (M, N) or (M, K, N)
            dtype: Data type (np.float32 or np.float64)
            flexibility: "strict" or "relaxed"
        
        Returns:
            ShapeRecommendation with dtype-aware optimization
        """
        # Normalize dtype
        dtype_key = dtype if dtype in self.sweet_spots else np.float64
        dtype_name = getattr(dtype, '__name__', str(dtype))
        
        sweet_spots = self.sweet_spots.get(dtype_key, {})
        gains = self.gains.get(dtype_key, {})
        
        if len(target) == 2:
            M, N = target
            K = None
        else:
            M, K, N = target
        
        M_opt, M_gain, M_reason = self._optimize_dim(M, sweet_spots, gains, flexibility)
        N_opt, N_gain, N_reason = self._optimize_dim(N, sweet_spots, gains, flexibility)
        
        if K is not None:
            K_opt, K_gain, K_reason = self._optimize_dim(K, sweet_spots, gains, flexibility)
            recommended = (M_opt, K_opt, N_opt)
            total_gain = max(M_gain, K_gain, N_gain)
            reasons = [r for r in [M_reason, K_reason, N_reason] if r]
        else:
            recommended = (M_opt, N_opt)
            total_gain = max(M_gain, N_gain)
            reasons = [r for r in [M_reason, N_reason] if r]
        
        if total_gain > 3:
            confidence = "high"
        elif total_gain > 0:
            confidence = "medium"
        else:
            confidence = "low"
        
        reasoning = "; ".join(reasons) if reasons else f"No optimization needed for {dtype_name}"
        
        return ShapeRecommendation(
            original=target,
            recommended=recommended,
            estimated_gain_pct=total_gain,
            reasoning=reasoning,
            confidence=confidence,
            dtype=dtype_name
        )
    
    def _optimize_dim(self, dim: int, sweet_spots: Dict, gains: Dict, 
                      flexibility: str) -> Tuple[int, float, str]:
        """Optimize a single dimension using dtype-specific sweet spots."""
        
        if dim <= 0:
            return dim, 0.0, ""
        
        # Check if dimension matches a known power of 2
        log2 = math.log2(dim)
        nearest_pow2 = 2 ** round(log2)
        
        # Check if we have a sweet spot for this
        if nearest_pow2 in sweet_spots:
            sweet = sweet_spots[nearest_pow2]
            gain = gains.get(nearest_pow2, 0)
            
            if dim == nearest_pow2 and sweet != nearest_pow2:
                return sweet, gain, f"{dim}→{sweet} (cache conflict avoidance, +{gain}%)"
            
            if abs(dim - nearest_pow2) <= 32 and flexibility == "relaxed":
                if sweet != dim:
                    return sweet, gain * 0.5, f"Adjusted {dim} to sweet spot {sweet}"
        
        return dim, 0.0, ""

# =============================================================================
# REUSE TRACKER
# =============================================================================

class ReuseTracker:
    """Track tensor reuse to decide copy vs view."""
    
    def __init__(self, profile: HardwareProfile):
        self.profile = profile
        self.breakeven = profile.transpose_breakeven
        self._tracked = {}
    
    def recommend(self, operation: str = "transpose",
                  reuse_count: int = 1) -> CopyRecommendation:
        
        if reuse_count >= self.breakeven:
            return CopyRecommendation(
                "copy",
                f"Reuse ({reuse_count}) >= breakeven ({self.breakeven:.0f})",
                self.breakeven,
                reuse_count
            )
        return CopyRecommendation(
            "view",
            f"Reuse ({reuse_count}) < breakeven ({self.breakeven:.0f})",
            self.breakeven,
            reuse_count
        )
    
    def track(self, tensor_id: str) -> int:
        self._tracked[tensor_id] = self._tracked.get(tensor_id, 0) + 1
        return self._tracked[tensor_id]

# =============================================================================
# LAYOUT ADVISOR
# =============================================================================

class LayoutAdvisor:
    """Recommend memory layout."""
    
    def __init__(self, profile: HardwareProfile):
        self.profile = profile
    
    def recommend(self, access_pattern: str = "row_major") -> LayoutRecommendation:
        layout = "C" if access_pattern != "column_major" else "F"
        return LayoutRecommendation(layout, f"Optimal for {access_pattern}", True)
    
    def check_contiguous(self, array: np.ndarray) -> Dict:
        is_c = array.flags['C_CONTIGUOUS']
        is_f = array.flags['F_CONTIGUOUS']
        return {
            "is_contiguous": is_c or is_f,
            "layout": "C" if is_c else ("F" if is_f else "neither"),
            "action": "none" if (is_c or is_f) else "copy"
        }

# =============================================================================
# MAIN RUNTIME
# =============================================================================

class AxonRT:
    """
    AXON Runtime v0.1.2 - Dtype-Aware Optimization
    
    BREAKTHROUGH: Shape recommendations now consider dtype!
    
    Usage:
        rt = AxonRT.auto_detect()
        
        # Dtype-aware recommendations
        shape_f64 = rt.recommend_shape((2048, 2048), dtype=np.float64)
        # → (2056, 2056) for float64
        
        shape_f32 = rt.recommend_shape((2048, 2048), dtype=np.float32)
        # → (2048, 2048) for float32
    """
    
    VERSION = "0.1.2"
    
    def __init__(self, profile: HardwareProfile):
        self.profile = profile
        self.precision_manager = PrecisionManager(profile)
        self.shape_recommender = ShapeRecommender(profile)
        self.reuse_tracker = ReuseTracker(profile)
        self.layout_advisor = LayoutAdvisor(profile)
        
        logger.info(f"AXON-RT v{self.VERSION} initialized (DTYPE-AWARE)")
        logger.info(f"Hardware: {profile.cpu_arch}, BLAS: {profile.blas_backend}")
    
    @classmethod
    def auto_detect(cls) -> 'AxonRT':
        import platform
        import os
        
        profile = HardwareProfile(
            hardware_id=platform.node(),
            timestamp=datetime.now().isoformat(),
            cpu_arch=platform.machine(),
            cpu_cores_logical=os.cpu_count() or 1,
        )
        
        # Try BLAS detection
        try:
            buf = StringIO()
            np.__config__.show(buf)
            config = buf.getvalue().lower()
            if 'openblas' in config:
                profile.blas_backend = "openblas"
            elif 'mkl' in config:
                profile.blas_backend = "mkl"
        except:
            pass
        
        # GPU detection
        try:
            import subprocess
            result = subprocess.run(['nvidia-smi', '-L'], 
                                    capture_output=True, text=True, timeout=2)
            if result.returncode == 0:
                profile.gpu_present = True
                profile.gpu_name = result.stdout.split('\n')[0]
        except:
            pass
        
        return cls(profile)
    
    @classmethod
    def from_profile(cls, path: str) -> 'AxonRT':
        profile = HardwareProfile.from_file(path)
        return cls(profile)
    
    def save_profile(self, path: str):
        self.profile.save(path)
    
    # =========================================================================
    # RECOMMENDATIONS (NOW DTYPE-AWARE!)
    # =========================================================================
    
    def recommend_shape(self, target: Tuple[int, ...], 
                        dtype=np.float64,
                        flexibility: str = "relaxed") -> ShapeRecommendation:
        """Get dtype-aware shape recommendation."""
        return self.shape_recommender.recommend(target, dtype, flexibility)
    
    def recommend_dtype(self, workload: str = "inference",
                        precision: str = "medium",
                        iterations: int = 1) -> DtypeRecommendation:
        return self.precision_manager.recommend(workload, precision, iterations)
    
    def should_copy(self, operation: str = "transpose",
                    reuse_count: int = 1) -> CopyRecommendation:
        return self.reuse_tracker.recommend(operation, reuse_count)
    
    def recommend_layout(self, access_pattern: str = "row_major") -> LayoutRecommendation:
        return self.layout_advisor.recommend(access_pattern)
    
    # =========================================================================
    # OPTIMIZATION
    # =========================================================================
    
    def optimize(self, array: np.ndarray, workload: str = "inference") -> np.ndarray:
        """Apply optimizations to array."""
        dtype_rec = self.recommend_dtype(workload)
        layout_check = self.layout_advisor.check_contiguous(array)
        
        result = array
        
        if dtype_rec.recommended != array.dtype:
            result = result.astype(dtype_rec.recommended)
        
        if not layout_check["is_contiguous"]:
            result = np.ascontiguousarray(result)
        
        return result
    
    def optimize_shape(self, target: Tuple[int, ...], 
                       dtype=np.float64) -> Tuple[int, ...]:
        """Get optimized shape for dtype."""
        return self.recommend_shape(target, dtype).recommended
    
    # =========================================================================
    # REPORTING
    # =========================================================================
    
    def report(self) -> str:
        lines = [
            "=" * 65,
            f"  AXON-RT v{self.VERSION} Status Report",
            "  ** NOW WITH DTYPE-AWARE SHAPE RECOMMENDATIONS **",
            "=" * 65,
            "",
            "Hardware Profile:",
            f"  Architecture: {self.profile.cpu_arch}",
            f"  Cores: {self.profile.cpu_cores_logical} logical",
            f"  BLAS: {self.profile.blas_backend}",
            f"  GPU: {'Yes - ' + self.profile.gpu_name if self.profile.gpu_present else 'No'}",
            "",
            "Optimization Rules:",
            f"  float32 speedup: ~{self.profile.float32_speedup:.2f}x vs float64",
            f"  Transpose breakeven: ~{self.profile.transpose_breakeven:.0f} reuses",
            "",
            "DTYPE-SPECIFIC SWEET SPOTS (v0.1.2 Discovery!):",
            "",
            "  float32 (prefers aligned powers of 2):",
            f"    {self.profile.sweet_spots_float32}",
            "",
            "  float64 (prefers conflict-breaking offsets):",
            f"    {self.profile.sweet_spots_float64}",
            "",
            "Physics: Different byte widths pack differently into 64-byte cache lines.",
            "         float32@2048 = 128 lines (good), float64@2048 = 256 lines (conflict!)",
            "",
            "=" * 65,
        ]
        return "\n".join(lines)


# =============================================================================
# CLI
# =============================================================================

def main():
    import argparse
    
    parser = argparse.ArgumentParser(description="AXON-RT v0.1.2 - Dtype-Aware")
    subparsers = parser.add_subparsers(dest='command')
    
    subparsers.add_parser('status', help='Show status')
    
    shape_p = subparsers.add_parser('recommend-shape', help='Get shape recommendation')
    shape_p.add_argument('dims', nargs='+', type=int)
    shape_p.add_argument('--dtype', choices=['float32', 'float64'], default='float64')
    
    dtype_p = subparsers.add_parser('recommend-dtype', help='Get dtype recommendation')
    dtype_p.add_argument('workload', choices=['reflex', 'inference', 'training', 'accumulation'])
    
    subparsers.add_parser('profile', help='Generate profile')
    
    args = parser.parse_args()
    rt = AxonRT.auto_detect()
    
    if args.command == 'status' or args.command is None:
        print(rt.report())
    
    elif args.command == 'recommend-shape':
        dtype = np.float32 if args.dtype == 'float32' else np.float64
        rec = rt.recommend_shape(tuple(args.dims), dtype=dtype)
        print(f"Target:       {rec.original}")
        print(f"Dtype:        {rec.dtype}")
        print(f"Recommended:  {rec.recommended}")
        print(f"Est. gain:    +{rec.estimated_gain_pct:.1f}%")
        print(f"Reasoning:    {rec.reasoning}")
    
    elif args.command == 'recommend-dtype':
        rec = rt.recommend_dtype(args.workload)
        print(f"Recommended:  {rec.recommended}")
        print(f"Speedup:      ~{rec.estimated_speedup:.2f}x")
        print(f"Reasoning:    {rec.reasoning}")
    
    elif args.command == 'profile':
        rt.save_profile('hardware_profile_v012.json')
        print("Profile saved to hardware_profile_v012.json")


if __name__ == "__main__":
    main()
